EnderIOEvents.conduits(event =>{
    event.registerEnergyConduit("viadium_conduit", "Viadium Energy Conduit", 512)
    event.registerEnergyConduit("sapatanium_conduit", "Sapatanium Energy Conduit", 2048)
    event.registerEnergyConduit("fechantium_conduit", "Fechantium Energy Conduit", 8192)
    event.registerEnergyConduit("yottrium_conduit", "Yottrium Energy Conduit", 32768)
    event.registerEnergyConduit("denisium_conduit", "Denisium Energy Conduit", 131072)
    event.registerEnergyConduit("avisium_conduit", "Avisium Energy Conduit", 524288) 
})