ServerEvents.recipes(event => {

    event.recipes.gtceu.assembler("sugar")
        .itemInputs("minecraft:sugar")
        .itemOutputs("minecraft:sugar")
        .duration(5)
        .EUt(1)
})